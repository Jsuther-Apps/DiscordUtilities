Extract with 7zip

This file was downloaded from the St0rm YouTube channel
https://youtube.com/st0rmyt